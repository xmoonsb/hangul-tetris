# 한글 테트리스 (Kids UI)

- 레포지토리: 예) `hangul-tetris`
- 배포 주소: `https://<your-id>.github.io/<repo>/` (예: `https://xmoonsb.github.io/hangul-tetris/`)

## 파일 목록
- `index.html` — 게임 본문 (유아 UI 적용)
- `404.html` — 없는 주소로 접근 시 홈으로 안내
- `.nojekyll` — GitHub Pages에서 Jekyll 처리 비활성화

## 배포(모바일)
1. GitHub 앱/웹 → `+` → New repository → 이름: `hangul-tetris` (Public)
2. 저장소 홈 → **Add file → Upload files** → 위 3개 파일 업로드 → Commit
3. **Settings → Pages** → Source: `Deploy from a branch` → Branch: `main` / Directory: `/ (root)` → Save
4. 상단에 나온 링크(예: `https://xmoonsb.github.io/hangul-tetris/`)로 접속

## 공유
- 블로그/메신저: 주소만 링크하거나 이미지에 링크를 걸어 사용.
- 저작권: 네이버 블로그 **밝음의근원** — https://m.blog.naver.com/xmoonsb